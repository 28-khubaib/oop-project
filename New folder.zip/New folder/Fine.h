#ifndef FINE_H
#define FINE_H
#include <iostream>
using namespace std;

class Fine {
public:
    double rate;
    int overdueDays;
    double totalFine;

    Fine() {
        rate = 10.0;
        overdueDays = 0;
        totalFine = 0;
    }

    void calculate(int days) {
        overdueDays = days;
        totalFine = rate * days;
    }

    void display(int days) {
        calculate(days);
        cout << "Fine: Rs. " << totalFine
             << " for " << overdueDays << " overdue days." << endl;
    }
};

#endif
